Sample text for archive.
